module.exports = {
    DATABASE: 'mongodb://localhost:27017/fashionCollection'
}
